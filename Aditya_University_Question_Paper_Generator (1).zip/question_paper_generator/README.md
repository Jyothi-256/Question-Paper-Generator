# Aditya University – Question Paper Generator

A Django full-stack project with:
- Dark-mood login and registration pages with the Aditya University logo.
- Dashboard for teachers/users.
- Subject, Unit and Question Bank management.
- Automatic 50-mark paper generation across 5 units.
- Two alternatives per unit, with each alternative totaling 10 marks.
- University-style HTML preview and downloadable A4 PDF.
- Django admin for direct question-bank management.

The uploaded university question-paper reference is used as the visual/content structure: university header, H.T.No/course code, semester/exam title, subject, time/max marks, instructions, UNIT sections, OR alternatives, Bloom level/CO/marks and closing stars.

## Windows execution

1. Install Python 3.11+.
2. Extract this ZIP.
3. Open Command Prompt in the extracted project folder.
4. Create a virtual environment:
   `python -m venv venv`
5. Activate it:
   `venv\\Scripts\\activate`
6. Install packages:
   `pip install -r requirements.txt`
7. Create database tables:
   `python manage.py makemigrations`
   `python manage.py migrate`
8. Create demo Data Structures subject, Units 1–5 and sample 5-mark questions:
   `python manage.py seed_demo`
9. Create an admin account if desired:
   `python manage.py createsuperuser`
10. Start server:
   `python manage.py runserver`
11. Open `http://127.0.0.1:8000/`

## First use

- Register a normal user, or use the superuser.
- Dashboard → Question Bank to see seeded questions.
- Add more questions using **Add Question**.
- Generate Paper → select Data Structures → Generate.
- Open preview and click **Download PDF**.
- Admin is at `http://127.0.0.1:8000/admin/`.

## Important generation rule

For each of Units 1–5, the generator searches the active question bank for four distinct questions that can be split into two pairs of 10 marks each. The reference paper has 50 marks total and instructs the student to answer one question from each unit. If a unit does not have enough compatible questions, the generator shows an error instead of producing an invalid paper.

## Adding 2M/4M/6M/8M questions

The generator is intentionally mark-aware. You can add mixed-mark questions through the question form or admin. For the exact reference-style 5+5 layout, keep enough 5-mark questions in each unit. For mixed patterns such as 2+8 or 6+4, add matching pairs totaling 10.

## Logo

`static/img/aditya_logo.png` is a cropped copy of the Aditya University logo/header from the supplied reference PDF.
