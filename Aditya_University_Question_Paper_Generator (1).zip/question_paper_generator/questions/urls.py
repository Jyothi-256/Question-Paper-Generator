from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('register/', views.register, name='register'),
    path('questions/add/', views.add_question, name='add_question'),
    path('questions/', views.question_list, name='question_list'),
    path('subjects/add/', views.add_subject, name='add_subject'),
    path('units/add/', views.add_unit, name='add_unit'),
    path('generate/', views.generate_paper, name='generate_paper'),
    path('papers/<int:paper_id>/', views.paper_preview, name='paper_preview'),
    path('papers/<int:paper_id>/pdf/', views.paper_pdf, name='paper_pdf'),
]
