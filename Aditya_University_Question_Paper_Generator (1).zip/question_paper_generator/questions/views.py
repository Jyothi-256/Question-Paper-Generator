from io import BytesIO
from itertools import combinations
import random

from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import Image as RLImage, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

from .forms import RegisterForm, QuestionForm, SubjectForm, UnitForm
from .models import PaperQuestion, Question, QuestionPaper, Subject, Unit


def home(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    return redirect('login')

@login_required
def dashboard(request):
    context = {
        'subjects': Subject.objects.all(),
        'question_count': Question.objects.count(),
        'paper_count': QuestionPaper.objects.count(),
        'recent_papers': QuestionPaper.objects.select_related('subject').all()[:6],
    }
    return render(request, 'questions/dashboard.html', context)

def register(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('dashboard')
    else:
        form = RegisterForm()
    return render(request, 'registration/register.html', {'form': form})

@login_required
def add_subject(request):
    form = SubjectForm(request.POST or None)
    if form.is_valid():
        form.save(); messages.success(request, 'Subject added successfully.'); return redirect('dashboard')
    return render(request, 'questions/form.html', {'form': form, 'title': 'Add Subject', 'back_url': 'dashboard'})

@login_required
def add_unit(request):
    form = UnitForm(request.POST or None)
    if form.is_valid():
        form.save(); messages.success(request, 'Unit added successfully.'); return redirect('dashboard')
    return render(request, 'questions/form.html', {'form': form, 'title': 'Add Unit', 'back_url': 'dashboard'})

@login_required
def add_question(request):
    form = QuestionForm(request.POST or None)
    if form.is_valid():
        q = form.save(commit=False)
        if q.unit.subject_id != q.subject_id:
            form.add_error('unit', 'Selected unit belongs to a different subject.')
        else:
            q.save()
            messages.success(request, 'Question added to the question bank.'); return redirect('question_list')
    return render(request, 'questions/form.html', {'form': form, 'title': 'Add Question', 'back_url': 'dashboard'})

@login_required
def question_list(request):
    questions = Question.objects.select_related('subject','unit').all()
    subject_id = request.GET.get('subject')
    unit_id = request.GET.get('unit')
    if subject_id: questions = questions.filter(subject_id=subject_id)
    if unit_id: questions = questions.filter(unit_id=unit_id)
    return render(request, 'questions/question_list.html', {'questions': questions, 'subjects': Subject.objects.all(), 'units': Unit.objects.all()})


def find_pair_groups(questions, target=10):
    qs = list(questions)
    random.shuffle(qs)
    pair_candidates = []
    for i in range(len(qs)):
        for j in range(i + 1, len(qs)):
            if qs[i].marks + qs[j].marks == target:
                pair_candidates.append((qs[i], qs[j]))
    random.shuffle(pair_candidates)
    for first in pair_candidates:
        used = {first[0].id, first[1].id}
        for second in pair_candidates:
            if second[0].id not in used and second[1].id not in used:
                return (first, second)
    return None

@login_required
def generate_paper(request):
    subjects = Subject.objects.all()
    if request.method == 'POST':
        subject = get_object_or_404(Subject, pk=request.POST.get('subject'))
        course_code = request.POST.get('course_code', subject.code)
        exam_title = request.POST.get('exam_title', 'B.Tech – Semester End Examinations Regular')
        semester = request.POST.get('semester', 'B.Tech – I Semester')
        session = request.POST.get('exam_session', 'Regular (B.Tech2024)')
        program_note = request.POST.get('program_note', 'Common to CSE, CSE(DS) & AIML')
        time_allowed = request.POST.get('time_allowed', '3 hours')

        paper = QuestionPaper.objects.create(
            subject=subject, course_code=course_code, exam_title=exam_title,
            semester=semester, exam_session=session, program_note=program_note,
            time_allowed=time_allowed, max_marks=50, created_by=request.user,
        )
        order = 1
        try:
            for unit_number in range(1, 6):
                qs = Question.objects.filter(subject=subject, unit__number=unit_number, active=True)
                groups = find_pair_groups(qs, 10)
                if not groups:
                    raise ValueError(f'Unit {unit_number} needs at least four active questions that can form two pairs totaling 10 marks each.')
                for alt_index, pair in enumerate(groups):
                    alt = 'A' if alt_index == 0 else 'B'
                    for part_index, q in enumerate(pair):
                        PaperQuestion.objects.create(paper=paper, question=q, unit_number=unit_number,
                            main_number=(unit_number * 2 - 1 if alt == 'A' else unit_number * 2),
                            alternative=alt, part_label='a' if part_index == 0 else 'b', order=order)
                        order += 1
        except Exception as exc:
            paper.delete()
            messages.error(request, str(exc))
            return render(request, 'questions/generate.html', {'subjects': subjects})
        return redirect('paper_preview', paper_id=paper.id)
    return render(request, 'questions/generate.html', {'subjects': subjects})

@login_required
def paper_preview(request, paper_id):
    paper = get_object_or_404(QuestionPaper.objects.select_related('subject'), pk=paper_id)
    rows = paper.paper_questions.select_related('question').all()
    unit_data = []
    for unit in range(1, 6):
        unit_rows = [r for r in rows if r.unit_number == unit]
        a = [r for r in unit_rows if r.alternative == 'A']
        b = [r for r in unit_rows if r.alternative == 'B']
        unit_data.append((unit, unit * 2 - 1, unit * 2, a, b))
    return render(request, 'questions/paper_preview.html', {'paper': paper, 'unit_data': unit_data})


def paper_pdf(request, paper_id):
    paper = get_object_or_404(QuestionPaper.objects.select_related('subject'), pk=paper_id)
    rows = list(paper.paper_questions.select_related('question').all())
    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4, rightMargin=16*mm, leftMargin=16*mm, topMargin=12*mm, bottomMargin=14*mm)
    styles = getSampleStyleSheet()
    center = ParagraphStyle('center', parent=styles['Normal'], alignment=TA_CENTER, fontName='Helvetica-Bold', fontSize=10, leading=12)
    title = ParagraphStyle('title', parent=center, fontSize=12, leading=14)
    small = ParagraphStyle('small', parent=styles['Normal'], fontSize=8.5, leading=10)
    qstyle = ParagraphStyle('q', parent=small, fontSize=8.5, leading=10)
    story = []
    logo_path = Path(__file__).resolve().parent.parent / 'static' / 'img' / 'aditya_logo.png'
    if logo_path.exists():
        logo = RLImage(str(logo_path), width=78*mm, height=21*mm)
        logo.hAlign = 'CENTER'
        story.append(logo)
    else:
        story.append(Paragraph('ADITYA UNIVERSITY', ParagraphStyle('uni', parent=center, fontSize=16, leading=18)))
    story.append(Paragraph(paper.semester + ' ' + paper.exam_session, center))
    story.append(Paragraph(paper.subject.name.upper(), title))
    story.append(Paragraph('(' + paper.program_note + ')', small))
    info = Table([[f'Time: {paper.time_allowed}', f'Max. Marks: {paper.max_marks}']], colWidths=[90*mm, 90*mm])
    info.setStyle(TableStyle([('FONTNAME',(0,0),(-1,-1),'Helvetica-Bold'),('FONTSIZE',(0,0),(-1,-1),9),('LINEBELOW',(0,0),(-1,-1),0.8,colors.black),('ALIGN',(0,0),(0,0),'LEFT'),('ALIGN',(1,0),(1,0),'RIGHT'),('BOTTOMPADDING',(0,0),(-1,-1),5)]))
    story += [Spacer(1,2*mm), info, Spacer(1,2*mm)]
    instr = Table([[Paragraph('<b>Answer ONE question from each unit</b>', center)], [Paragraph('<b>All Questions Carry Equal Marks</b>', center)], [Paragraph('<b>All parts of the questions must be answered at one place only</b>', center)]], colWidths=[180*mm])
    instr.setStyle(TableStyle([('LINEABOVE',(0,0),(-1,0),0.7,colors.black),('LINEBELOW',(0,-1),(-1,-1),0.7,colors.black),('TOPPADDING',(0,0),(-1,-1),2),('BOTTOMPADDING',(0,0),(-1,-1),2)]))
    story.append(instr)
    for unit in range(1,6):
        story.append(Spacer(1,2.5*mm))
        story.append(Paragraph(f'<b>UNIT-{unit}</b>', ParagraphStyle('unit', parent=small, fontSize=9, leading=10)))
        unit_rows = [r for r in rows if r.unit_number == unit]
        for alt, num in [('A', unit*2-1), ('B', unit*2)]:
            altrows = [r for r in unit_rows if r.alternative == alt]
            cells = [[Paragraph(f'<b>{num}</b>', qstyle), Paragraph('', qstyle), Paragraph('', qstyle), Paragraph('', qstyle)]]
            cells = []
            for r in altrows:
                q = r.question
                cells.append([Paragraph(f'<b>{num if r.part_label=="a" else ""}</b>', qstyle), Paragraph(r.part_label, qstyle), Paragraph(q.question_text, qstyle), Paragraph(f'{q.bloom_level} &nbsp;&nbsp; {q.course_outcome} &nbsp;&nbsp; [{q.marks}M]', qstyle)])
            t = Table(cells, colWidths=[8*mm, 7*mm, 130*mm, 35*mm])
            t.setStyle(TableStyle([('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),1),('RIGHTPADDING',(0,0),(-1,-1),1),('TOPPADDING',(0,0),(-1,-1),1),('BOTTOMPADDING',(0,0),(-1,-1),1)]))
            story.append(t)
            if alt == 'A': story.append(Paragraph('<b>(OR)</b>', ParagraphStyle('or', parent=center, fontSize=8, leading=9)))
    story.append(Spacer(1,5*mm))
    story.append(Paragraph('*****', center))
    doc.build(story)
    pdf = buffer.getvalue(); buffer.close()
    response = HttpResponse(pdf, content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="{paper.course_code}_question_paper.pdf"'
    return response
