from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import Question, Subject, Unit

class RegisterForm(UserCreationForm):
    email = forms.EmailField(required=True)
    class Meta:
        model = User
        fields = ('username', 'email', 'password1', 'password2')

class QuestionForm(forms.ModelForm):
    class Meta:
        model = Question
        fields = ('subject', 'unit', 'question_text', 'question_type', 'marks', 'difficulty', 'bloom_level', 'course_outcome', 'active')
        widgets = {'question_text': forms.Textarea(attrs={'rows': 4})}

class SubjectForm(forms.ModelForm):
    class Meta:
        model = Subject
        fields = ('name', 'code')

class UnitForm(forms.ModelForm):
    class Meta:
        model = Unit
        fields = ('subject', 'number', 'title')
