from django.contrib import admin
from .models import Subject, Unit, Question, QuestionPaper, PaperQuestion

@admin.register(Subject)
class SubjectAdmin(admin.ModelAdmin):
    list_display = ('name', 'code')
    search_fields = ('name', 'code')

@admin.register(Unit)
class UnitAdmin(admin.ModelAdmin):
    list_display = ('number', 'title', 'subject')
    list_filter = ('subject',)

@admin.register(Question)
class QuestionAdmin(admin.ModelAdmin):
    list_display = ('id', 'question_text', 'subject', 'unit', 'marks', 'difficulty', 'bloom_level', 'course_outcome', 'active')
    list_filter = ('subject', 'unit', 'marks', 'difficulty', 'active')
    search_fields = ('question_text',)

class PaperQuestionInline(admin.TabularInline):
    model = PaperQuestion
    extra = 0

@admin.register(QuestionPaper)
class QuestionPaperAdmin(admin.ModelAdmin):
    list_display = ('id', 'subject', 'course_code', 'max_marks', 'created_by', 'created_at')
    list_filter = ('subject', 'created_at')
    inlines = [PaperQuestionInline]
