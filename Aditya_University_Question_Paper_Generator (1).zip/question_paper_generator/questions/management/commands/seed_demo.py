from django.core.management.base import BaseCommand
from questions.models import Subject, Unit, Question

DATA = {
'DATA STRUCTURES': [
['Arrays','Define an array and explain its basic operations with an example.','Explain insertion and deletion operations in a one-dimensional array.','Compare one-dimensional and two-dimensional arrays with examples.','Explain how arrays are stored in contiguous memory locations.','Write an algorithm to find the maximum and minimum elements in an array.','Explain linear search and its time complexity.','Explain binary search and state the condition required for it.','Write an algorithm to reverse an array in-place.'],
['Linked Lists','Define a linked list and explain the structure of a node.','Explain insertion at the beginning and end of a singly linked list.','Differentiate singly, doubly and circular linked lists.','Explain deletion of a node from a singly linked list.','Write an algorithm to traverse a linked list.','Explain the advantages of linked lists over arrays.','Describe circular linked lists with a neat example.','Explain how to reverse a singly linked list.'],
['Stacks','Define stack and explain the PUSH and POP operations.','Explain stack implementation using arrays.','Explain stack implementation using linked lists.','Describe applications of stacks in expression processing.','Convert an infix expression to postfix using a stack.','Explain overflow and underflow conditions in stacks.','Differentiate stack and queue.','Explain recursion using stack memory.'],
['Queues','Define queue and explain ENQUEUE and DEQUEUE operations.','Explain circular queue with an example.','Differentiate linear queue, circular queue and deque.','Explain queue implementation using linked lists.','Describe priority queues and their applications.','Write an algorithm for insertion in a circular queue.','Explain overflow and underflow in queues.','Describe real-world applications of queues.'],
['Trees','Define a tree and explain basic terminology such as root, leaf and degree.','Explain binary tree representation using arrays and linked structures.','Differentiate binary tree and binary search tree.','Explain preorder, inorder and postorder traversals with an example.','Write an algorithm for insertion in a binary search tree.','Explain deletion in a binary search tree.','Describe AVL trees and the need for balancing.','Explain the applications of tree data structures.']]
}

class Command(BaseCommand):
    help = 'Create demo subject, five units and question-bank entries.'
    def handle(self, *args, **options):
        subject, _ = Subject.objects.get_or_create(name='Data Structures', code='24CSDS001')
        units = DATA['DATA STRUCTURES']
        for idx, pair in enumerate(units, 1):
            title = pair[0]
            unit, _ = Unit.objects.get_or_create(subject=subject, number=idx, defaults={'title': title})
            unit.title = title; unit.save()
            for text in pair[1:]:
                Question.objects.get_or_create(subject=subject, unit=unit, question_text=text, defaults={'marks':5,'difficulty':'Medium','bloom_level':'L2','course_outcome':f'CO{idx}','question_type':'Short'})
        self.stdout.write(self.style.SUCCESS('Demo question bank created. Use Data Structures / 24CSDS001.'))
