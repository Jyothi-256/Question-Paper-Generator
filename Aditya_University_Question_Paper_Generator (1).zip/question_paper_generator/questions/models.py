from django.contrib.auth.models import User
from django.db import models

class Subject(models.Model):
    name = models.CharField(max_length=200)
    code = models.CharField(max_length=50, unique=True)

    def __str__(self):
        return f'{self.name} ({self.code})'

class Unit(models.Model):
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE, related_name='units')
    number = models.PositiveIntegerField()
    title = models.CharField(max_length=200)

    class Meta:
        ordering = ['subject', 'number']
        unique_together = ('subject', 'number')

    def __str__(self):
        return f'UNIT-{self.number}: {self.title}'

class Question(models.Model):
    TYPE_CHOICES = [('MCQ','MCQ'), ('Short','Short Answer'), ('Long','Long Answer'), ('Problem','Problem')]
    DIFFICULTY_CHOICES = [('Easy','Easy'), ('Medium','Medium'), ('Hard','Hard')]
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE, related_name='questions')
    unit = models.ForeignKey(Unit, on_delete=models.CASCADE, related_name='questions')
    question_text = models.TextField()
    question_type = models.CharField(max_length=20, choices=TYPE_CHOICES, default='Short')
    marks = models.PositiveIntegerField(default=5)
    difficulty = models.CharField(max_length=20, choices=DIFFICULTY_CHOICES, default='Medium')
    bloom_level = models.CharField(max_length=20, default='L2')
    course_outcome = models.CharField(max_length=20, default='CO1')
    active = models.BooleanField(default=True)

    class Meta:
        ordering = ['unit', 'id']

    def __str__(self):
        return f'{self.question_text[:80]} [{self.marks}M]'

class QuestionPaper(models.Model):
    exam_title = models.CharField(max_length=250, default='B.Tech – Semester End Examinations Regular')
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE, related_name='papers')
    course_code = models.CharField(max_length=50)
    semester = models.CharField(max_length=100, default='B.Tech – I Semester')
    exam_session = models.CharField(max_length=100, default='Regular (B.Tech2024)')
    program_note = models.CharField(max_length=250, default='Common to CSE, CSE(DS) & AIML')
    time_allowed = models.CharField(max_length=50, default='3 hours')
    max_marks = models.PositiveIntegerField(default=50)
    created_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f'{self.subject.name} - {self.course_code} - {self.created_at:%Y-%m-%d %H:%M}'

class PaperQuestion(models.Model):
    paper = models.ForeignKey(QuestionPaper, on_delete=models.CASCADE, related_name='paper_questions')
    question = models.ForeignKey(Question, on_delete=models.PROTECT)
    unit_number = models.PositiveIntegerField()
    main_number = models.PositiveIntegerField()
    alternative = models.CharField(max_length=1, choices=[('A','A'),('B','B')])
    part_label = models.CharField(max_length=1, choices=[('a','a'),('b','b')])
    order = models.PositiveIntegerField()

    class Meta:
        ordering = ['order']
